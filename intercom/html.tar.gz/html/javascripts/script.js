$(function(){
	if ($(".slider").length) {
		var swiper = new Swiper('.swiper-container', {
			pagination: '.swiper-pagination',
			paginationClickable: true,
			spaceBetween: 30,
			loop: true,
			centeredSlides: true,
			autoplay: 2500,
			autoplayDisableOnInteraction: false
		});
	}
   
    if ($("ul#tabs").length) {
		$("ul#tabs li").click(function(e){
			if (!$(this).hasClass("active")) {
				var tabNum = $(this).index();
				var nthChild = tabNum+1;
				$("ul#tabs li.active").removeClass("active");
				$(this).addClass("active");
				$("ul#tab li.active").removeClass("active");
				$("ul#tab li:nth-child("+nthChild+")").addClass("active");
			}
			setTimeout(function () {
			   swiperPlaylist.update();
			  }, 500);
		});
	}
	
	if($('.playlist').length){
		var swiperPlaylist = new Swiper('.swiper-container', {
			pagination: '.swiper-pagination',
			slidesPerView: 5,
			direction: 'vertical',
			paginationClickable: false,
			nextButton: '.swiper-button-next',
        	prevButton: '.swiper-button-prev',
			autoHeight:true,
			preloadImages:true
		});
		$(".plist .swiper-slide").on("click", function() {
			console.log($(this).index())
			$(".plist .swiper-slide").removeClass('active');
			$(this).addClass('active');
			$("#videoarea").attr({
				"src": $(this).attr("movieurl"),
				"autoplay": "autoplay"
			})
		})
		$("#videoarea").attr({
			"src": $(".plist .swiper-slide").eq(0).attr("movieurl"),
			"poster": $(".plist .swiper-slide").eq(0).attr("moviesposter")
		})
		
	}
	
	if($('.timelineContainer').length){
		var timelineBlocks = $('.cd-timeline-block'),
		offset = 0.8;

		//hide timeline blocks which are outside the viewport
		hideBlocks(timelineBlocks, offset);
	
		//on scolling, show/animate timeline blocks when enter the viewport
		$(window).on('scroll', function(){
			(!window.requestAnimationFrame) 
				? setTimeout(function(){ showBlocks(timelineBlocks, offset); }, 100)
				: window.requestAnimationFrame(function(){ showBlocks(timelineBlocks, offset); });
		});
	
		function hideBlocks(blocks, offset) {
			blocks.each(function(){
				( $(this).offset().top > $(window).scrollTop()+$(window).height()*offset ) && $(this).find('.cd-timeline-img, .cd-timeline-content').addClass('is-hidden');
			});
		}
	
		function showBlocks(blocks, offset) {
			blocks.each(function(){
				( $(this).offset().top <= $(window).scrollTop()+$(window).height()*offset && $(this).find('.cd-timeline-img').hasClass('is-hidden') ) && $(this).find('.cd-timeline-img, .cd-timeline-content').removeClass('is-hidden').addClass('bounce-in');
			});
		}
		
		$('.cd-read-more').click(function(){
			$('.cd-read-more').show();
			$(this).hide();
			
			$('.cd-timeline-block').removeClass('cd-force-white');
			$(this).closest('.cd-timeline-block').addClass('cd-force-white');
			
			$('.cd-short-content').show();
			$(this).prev().hide();
			
			$('.cd-view-more').hide();
			$(this).next('.cd-view-more').show();
		});
	}
	
	// 设置为主页 
	

	
});
function SetHome(obj, vrl) {
		try {
			obj.style.behavior = 'url(#default#homepage)'; obj.setHomePage(vrl);
		}
		catch (e) {
			if (window.netscape) {
				try {
					netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
				}
				catch (e) {
					alert("此操作被浏览器拒绝！\n请在浏览器地址栏输入“about:config”并回车\n然后将 [signed.applets.codebase_principal_support]的值设置为'true',双击即可。");
				}
				var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
				prefs.setCharPref('browser.startup.homepage', vrl);
			} else {
				alert("您的浏览器不支持，请按照下面步骤操作：1.打开浏览器设置。2.点击设置网页。3.输入：" + vrl + "点击确定。");
			}
		}
	}
	// 加入收藏 兼容360和IE6 
	function shoucang(sTitle, sURL) {
		try {
			window.external.addFavorite(sURL, sTitle);
		}
		catch (e) {
			try {
				window.sidebar.addPanel(sTitle, sURL, "");
			}
			catch (e) {
				alert("加入收藏失败，请使用Ctrl+D进行添加");
			}
		}
	} 